
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","_echo()"],["c","cURL"],["c","Downloader"],["c","Format"],["f","get()"],["c","Handler"],["c","IO"],["c","Memcache"],["c","MemcachePool"],["c","Router"],["c","Service"],["c","Settings"],["c","Setup"],["c","Setup\\AbstractBinSetup"],["c","Setup\\AbstractSetup"],["c","Setup\\Apache"],["c","Setup\\Memcache"],["c","Setup\\MySQL"],["c","Setup\\PHP"],["c","Setup\\Redis"],["c","VersionSwitch\\AbstractVersionSwitch"],["c","VersionSwitch\\Apache"],["c","VersionSwitch\\MySQL"],["c","VersionSwitch\\PHP"],["c","VersionSwitch\\Redis"]];
